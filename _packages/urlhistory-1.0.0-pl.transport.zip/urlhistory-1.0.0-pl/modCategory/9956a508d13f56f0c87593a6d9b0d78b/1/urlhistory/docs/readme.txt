--------------------
UrlHistory
--------------------
Version: 1.0.0
Author: Jiri Pavlicek <jiri@pavlicek.cz>
--------------------

UrlHistory for MODx Revolution saves old document urls and redirects from old urls to new url.

Feel free to suggest ideas/improvements/bugs on GitHub:
http://github.com/jiripavlicek/UrlHistory/issues