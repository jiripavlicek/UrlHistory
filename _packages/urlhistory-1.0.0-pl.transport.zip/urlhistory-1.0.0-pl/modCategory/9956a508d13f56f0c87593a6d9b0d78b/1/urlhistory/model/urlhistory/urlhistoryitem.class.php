<?php
/**
 * @property string $url
 * @property string $short
 * @property int $clicks
 *
 * @package urlhistory
 */
class UrlHistoryItem extends xPDOSimpleObject {}
?>